# data

A set of dependency free data structures in C++

```
[env:node32s]
platform = espressif32
board = node32s
framework = arduino
lib_deps = 
	codewitch-honey-crisis/htcw_data@^1.0.1
```